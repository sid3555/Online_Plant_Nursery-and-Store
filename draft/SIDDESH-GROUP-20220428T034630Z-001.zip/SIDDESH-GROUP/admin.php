<?php

	// $servername = 'localhost';
	$servername = '127.0.0.1:3306';
	$username = 'root';
	$password = '';
	$database = 'plant_db';

	// Creating database connection
	$conn = mysqli_connect($servername, $username, $password, $database);

	// Check connection
	if (!$conn) {
		die("Failed to Connect" . mysqli_connect_error());
		exit();
	}
	
	$admin_name = mysqli_real_escape_string($conn, $_REQUEST['adminName']);
	$admin_pass = mysqli_real_escape_string($conn, $_REQUEST['Password']);

    $sql = "SELECT admin_name, password FROM admin WHERE admin_name='$admin_name' AND password='$admin_pass';";
	
	if(mysqli_query($conn, $sql)) {
		echo "<script>SUCCESS</script>";
		header("Location: admin-data.php");
	}
	else{
		header("Location: admin.html");
	}

	mysqli_close($conn);
?>