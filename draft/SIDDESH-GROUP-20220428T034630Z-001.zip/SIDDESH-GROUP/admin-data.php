<?php
        $conn = mysqli_connect('127.0.0.1:3307', 'root', '', 'plant_db');
        if(!$conn){
            echo "CONNECTION FAILED!!!!!!";
            exit();
        }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PAGE</title>
</head>
<body>
    <table align = "center" border = "1px" style = "width : 1200px; line-height : 40px;">
        <tr><th colspan = "6"><h2>USER INFORMATION</h2></th></tr>
        <tr>
            <th>ID</th>
            <th>FIRSTNAME</th>
            <th>LASTNAME</th>
            <th>EMAIL ID</th>
            <th>ADDRESS</th>
            <th>PASSWORD</th>
        </tr>
        <?php
            $sql_query = 'select * from users';
            $result = mysqli_query($conn, $sql_query);
        
            while($row = mysqli_fetch_assoc($result))
            {
        ?>

        <tr>
            <td><?php echo $row['Id']; ?></td>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['password']; ?></td>
        </tr>
        
        <?php
            }
            mysqli_close($conn);
        ?>
    </table>
</body>
</html>