<?php  

        //creating variables for database connection
	    $servername = '127.0.0.1:3306';
	    $username = 'root';
	    $password = '';
	    $database = 'plant_db';
        
        //database connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        
        // checking the connection
        if($conn->connect_error) {
            die('Connection Failed  : ' . $conn->connect_error);
            exit();
        }

        //taking value from the login form in the defined variables
    	$firstname = mysqli_real_escape_string($conn, $_REQUEST['FirstName']);
    	$lastname = mysqli_real_escape_string($conn, $_REQUEST['LastName']);
    	$email = mysqli_real_escape_string($conn, $_REQUEST['EmailId']);
    	$address = mysqli_real_escape_string($conn, $_REQUEST['Address']);
    	$pass = mysqli_real_escape_string($conn, $_REQUEST['Password']);

        //query for insert of user data
    	$sql_query = "INSERT INTO users (first_name, last_name, email, address, password) VALUES ('$firstname', '$lastname', '$email', '$address', '$pass');";

    	if (mysqli_query($conn, $sql_query)) {
    		echo "<script>Your message was sent successfully!</script>";
	        header("Location: index.html");            
    	}
    	else {
    		echo "<script>Your message could not be sent!</script>";
    	}
		
		mysqli_close($conn);
?>